/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, 
  Map as MapIcon, 
  Grid, 
  Plus, 
  LogOut, 
  Search, 
  Info, 
  MapPin, 
  Calendar, 
  Tag, 
  ChevronRight, 
  X, 
  Loader2,
  Upload,
  User as UserIcon,
  Globe,
  Lock,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot, 
  serverTimestamp, 
  doc, 
  setDoc,
  deleteDoc,
  getDocFromServer
} from 'firebase/firestore';
import { 
  ref, 
  uploadBytes, 
  getDownloadURL 
} from 'firebase/storage';
import { useAuthState } from 'react-firebase-hooks/auth';
import { useCollectionData } from 'react-firebase-hooks/firestore';
import { format } from 'date-fns';
import { GoogleGenAI } from "@google/genai";

import { auth, db, storage } from './firebase';
import { cn } from './lib/utils';

// --- Types ---

interface Sighting {
  id: string;
  userId: string;
  species: string;
  commonName?: string;
  scientificName?: string;
  behavior?: string;
  notes?: string;
  imageUrl?: string;
  latitude?: number;
  longitude?: number;
  locationName?: string;
  timestamp: any;
  isPublic: boolean;
  tags?: string[];
}

// --- Components ---

const ErrorBoundary = ({ children }: { children: React.ReactNode }) => {
  const [hasError, setHasError] = useState(false);
  const [errorInfo, setErrorInfo] = useState<string | null>(null);

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      setHasError(true);
      setErrorInfo(event.message);
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-red-50 p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Something went wrong</h1>
          <p className="text-gray-600 mb-6">{errorInfo || "An unexpected error occurred."}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-red-600 text-white px-6 py-2 rounded-full font-medium hover:bg-red-700 transition-colors"
          >
            Reload App
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default function App() {
  const [user, loading, error] = useAuthState(auth);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setIsAuthReady(true);
      if (u) {
        // Sync user to firestore
        const userRef = doc(db, 'users', u.uid);
        setDoc(userRef, {
          uid: u.uid,
          displayName: u.displayName,
          email: u.email,
          photoURL: u.photoURL,
          createdAt: serverTimestamp()
        }, { merge: true });
      }
    });
    return () => unsubscribe();
  }, []);

  // Test connection
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  if (loading || !isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <Loader2 className="w-12 h-12 text-stone-400 animate-spin" />
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-stone-50 text-stone-900 font-sans selection:bg-stone-200">
        {!user ? <LoginScreen /> : <Dashboard user={user} />}
      </div>
    </ErrorBoundary>
  );
}

function LoginScreen() {
  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-emerald-100/30 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-amber-100/30 rounded-full blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="z-10 text-center max-w-lg"
      >
        <div className="inline-flex items-center justify-center w-20 h-20 bg-stone-900 text-white rounded-3xl mb-8 shadow-2xl shadow-stone-900/20">
          <Camera className="w-10 h-10" />
        </div>
        <h1 className="text-6xl font-serif font-light tracking-tight mb-4">WildLens</h1>
        <p className="text-stone-500 text-lg mb-12 leading-relaxed">
          The premier wildlife photo management ecosystem. Transform your sightings into a data-rich, shareable catalog.
        </p>
        
        <button 
          onClick={handleLogin}
          className="group relative flex items-center gap-4 bg-stone-900 text-white px-8 py-4 rounded-2xl font-medium hover:bg-stone-800 transition-all shadow-xl hover:shadow-2xl active:scale-95"
        >
          <Globe className="w-5 h-5 group-hover:rotate-12 transition-transform" />
          Connect with Google
        </button>
        
        <div className="mt-12 flex gap-8 justify-center text-stone-400 text-sm font-medium uppercase tracking-widest">
          <span>Identify</span>
          <span>Catalog</span>
          <span>Map</span>
        </div>
      </motion.div>
    </div>
  );
}

function Dashboard({ user }: { user: User }) {
  const [view, setView] = useState<'grid' | 'map'>('grid');
  const [isAdding, setIsAdding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const sightingsQuery = query(
    collection(db, 'sightings'),
    where('userId', '==', user.uid),
    orderBy('timestamp', 'desc')
  );

  const [sightings, loading] = useCollectionData(sightingsQuery);

  const filteredSightings = (sightings as Sighting[] | undefined)?.filter(s => 
    s.species.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.commonName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.locationName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 mb-12">
        <div>
          <h2 className="text-4xl font-serif font-light mb-1">My Sightings</h2>
          <p className="text-stone-500">Welcome back, {user.displayName?.split(' ')[0]}</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input 
              type="text" 
              placeholder="Search species or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5 transition-all w-64"
            />
          </div>
          
          <div className="flex bg-white border border-stone-200 rounded-xl p-1">
            <button 
              onClick={() => setView('grid')}
              className={cn(
                "p-2 rounded-lg transition-colors",
                view === 'grid' ? "bg-stone-900 text-white" : "text-stone-400 hover:text-stone-600"
              )}
            >
              <Grid className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setView('map')}
              className={cn(
                "p-2 rounded-lg transition-colors",
                view === 'map' ? "bg-stone-900 text-white" : "text-stone-400 hover:text-stone-600"
              )}
            >
              <MapIcon className="w-5 h-5" />
            </button>
          </div>

          <button 
            onClick={() => signOut(auth)}
            className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
            title="Logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-stone-300 animate-spin" />
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsAdding(true)}
            className="aspect-[4/5] flex flex-col items-center justify-center border-2 border-dashed border-stone-200 rounded-3xl hover:border-stone-400 hover:bg-white transition-all group"
          >
            <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-stone-900 group-hover:text-white transition-colors">
              <Plus className="w-8 h-8" />
            </div>
            <span className="font-medium text-stone-600">Add New Sighting</span>
          </motion.button>

          {filteredSightings?.map((sighting) => (
            // @ts-ignore - key is handled by React
            <SightingCard key={sighting.id || Math.random().toString()} sighting={sighting} />
          ))}
        </div>
      ) : (
        <MapView sightings={filteredSightings || []} />
      )}

      {/* Add Sighting Modal */}
      <AnimatePresence>
        {isAdding && (
          <AddSightingModal 
            user={user} 
            onClose={() => setIsAdding(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function SightingCard({ sighting }: { sighting: Sighting }) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (window.confirm("Are you sure you want to delete this sighting?")) {
      setIsDeleting(true);
      try {
        await deleteDoc(doc(db, 'sightings', sighting.id));
      } catch (err) {
        console.error("Delete failed:", err);
      } finally {
        setIsDeleting(false);
      }
    }
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="group bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-sm hover:shadow-xl transition-all"
    >
      <div className="aspect-[4/5] relative overflow-hidden bg-stone-100">
        {sighting.imageUrl ? (
          <img 
            src={sighting.imageUrl} 
            alt={sighting.species}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-stone-300">
            <Camera className="w-12 h-12" />
          </div>
        )}
        
        <div className="absolute top-4 right-4 flex gap-2">
          {sighting.isPublic ? (
            <div className="bg-white/90 backdrop-blur p-2 rounded-full shadow-sm" title="Public">
              <Globe className="w-4 h-4 text-emerald-600" />
            </div>
          ) : (
            <div className="bg-white/90 backdrop-blur p-2 rounded-full shadow-sm" title="Private">
              <Lock className="w-4 h-4 text-stone-400" />
            </div>
          )}
          <button 
            onClick={handleDelete}
            disabled={isDeleting}
            className="bg-white/90 backdrop-blur p-2 rounded-full shadow-sm text-stone-400 hover:text-red-600 transition-colors"
          >
            {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
          </button>
        </div>

        <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-black/60 to-transparent text-white">
          <h3 className="text-xl font-medium mb-1">{sighting.species}</h3>
          {sighting.commonName && <p className="text-sm text-white/80 italic">{sighting.commonName}</p>}
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-center gap-2 text-stone-500 text-sm mb-4">
          <Calendar className="w-4 h-4" />
          <span>{sighting.timestamp?.toDate ? format(sighting.timestamp.toDate(), 'MMM d, yyyy') : 'Recently'}</span>
          {sighting.locationName && (
            <>
              <span className="w-1 h-1 bg-stone-300 rounded-full" />
              <MapPin className="w-4 h-4" />
              <span className="truncate">{sighting.locationName}</span>
            </>
          )}
        </div>
        
        {sighting.notes && (
          <p className="text-stone-600 text-sm line-clamp-2 mb-4 leading-relaxed">
            {sighting.notes}
          </p>
        )}

        <div className="flex flex-wrap gap-2">
          {sighting.tags?.map(tag => (
            <span key={tag} className="px-2 py-1 bg-stone-100 text-stone-500 text-[10px] font-bold uppercase tracking-wider rounded-md">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function MapView({ sightings }: { sightings: Sighting[] }) {
  return (
    <div className="bg-white border border-stone-200 rounded-3xl p-8 min-h-[500px] flex flex-col items-center justify-center text-center">
      <div className="w-20 h-20 bg-stone-50 rounded-full flex items-center justify-center mb-6">
        <MapIcon className="w-10 h-10 text-stone-300" />
      </div>
      <h3 className="text-2xl font-serif mb-2">Interactive Map View</h3>
      <p className="text-stone-500 max-w-md mx-auto mb-8">
        Visualizing {sightings.length} sightings across the globe. (Map integration would typically use Mapbox or Google Maps).
      </p>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full max-w-2xl">
        {sightings.filter(s => s.latitude && s.longitude).map(s => (
          <div key={s.id} className="p-4 bg-stone-50 rounded-2xl text-left">
            <p className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">Location</p>
            <p className="text-sm font-medium truncate">{s.locationName || 'Unknown'}</p>
            <p className="text-[10px] text-stone-400 font-mono mt-1">
              {s.latitude?.toFixed(4)}, {s.longitude?.toFixed(4)}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AddSightingModal({ user, onClose }: { user: User, onClose: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isIdentifying, setIsIdentifying] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    species: '',
    commonName: '',
    scientificName: '',
    behavior: '',
    notes: '',
    locationName: '',
    isPublic: true,
    tags: [] as string[]
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(selected);
      identifySpecies(selected);
    }
  };

  const identifySpecies = async (imageFile: File) => {
    setIsIdentifying(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

      const reader = new FileReader();
      reader.readAsDataURL(imageFile);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        
        const prompt = `Identify the wildlife in this image. Provide the common name, scientific name, and a brief description of its typical behavior. Return the result in JSON format with keys: species, commonName, scientificName, behavior, tags (array of 3-5 keywords).`;
        
        const result = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: [{
            parts: [
              { text: prompt },
              { inlineData: { mimeType: imageFile.type, data: base64Data } }
            ]
          }],
          config: { responseMimeType: "application/json" }
        });

        const data = JSON.parse(result.text || '{}');
        setFormData(prev => ({
          ...prev,
          species: data.species || data.commonName,
          commonName: data.commonName,
          scientificName: data.scientificName,
          behavior: data.behavior,
          tags: data.tags || []
        }));
        setIsIdentifying(false);
      };
    } catch (err) {
      console.error("Identification failed:", err);
      setIsIdentifying(false);
    }
  };

  const handleSave = async () => {
    if (!formData.species) return;
    setIsSaving(true);

    try {
      let imageUrl = '';
      if (file) {
        const storageRef = ref(storage, `sightings/${user.uid}/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(storageRef, file);
        imageUrl = await getDownloadURL(snapshot.ref);
      }

      // Get location if possible
      let lat, lng;
      try {
        const pos = await new Promise<GeolocationPosition>((res, rej) => 
          navigator.geolocation.getCurrentPosition(res, rej, { timeout: 5000 })
        );
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
      } catch (e) {
        console.warn("Location access denied or timed out");
      }

      await addDoc(collection(db, 'sightings'), {
        ...formData,
        userId: user.uid,
        imageUrl,
        latitude: lat || null,
        longitude: lng || null,
        timestamp: serverTimestamp()
      });

      onClose();
    } catch (err) {
      console.error("Save failed:", err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white w-full max-w-4xl max-h-[90vh] rounded-[40px] shadow-2xl overflow-hidden flex flex-col md:flex-row"
      >
        {/* Left: Image Upload/Preview */}
        <div className="w-full md:w-1/2 bg-stone-100 relative flex flex-col items-center justify-center p-8 border-b md:border-b-0 md:border-r border-stone-200">
          {preview ? (
            <div className="w-full h-full relative group">
              <img 
                src={preview} 
                alt="Preview" 
                className="w-full h-full object-cover rounded-3xl shadow-lg" 
              />
              <button 
                onClick={() => { setFile(null); setPreview(null); }}
                className="absolute top-4 right-4 bg-white/90 backdrop-blur p-2 rounded-full shadow-md text-stone-900 hover:text-red-600 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
              {isIdentifying && (
                <div className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm rounded-3xl flex flex-col items-center justify-center text-white p-6 text-center">
                  <Loader2 className="w-10 h-10 animate-spin mb-4" />
                  <p className="text-lg font-medium">Analyzing species...</p>
                  <p className="text-sm text-white/70 mt-2">Our AI is identifying the wildlife in your photo.</p>
                </div>
              )}
            </div>
          ) : (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-full flex flex-col items-center justify-center border-4 border-dashed border-stone-200 rounded-[32px] cursor-pointer hover:border-stone-400 hover:bg-stone-50 transition-all group p-12 text-center"
            >
              <div className="w-20 h-20 bg-stone-200 rounded-full flex items-center justify-center mb-6 group-hover:bg-stone-900 group-hover:text-white transition-all">
                <Upload className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-medium text-stone-900 mb-2">Upload Photo</h3>
              <p className="text-stone-500 text-sm">Drag and drop or click to select a wildlife photo from your device.</p>
            </div>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            className="hidden" 
            accept="image/*" 
          />
        </div>

        {/* Right: Form Details */}
        <div className="w-full md:w-1/2 p-8 md:p-12 overflow-y-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-serif">Sighting Details</h2>
            <button onClick={onClose} className="text-stone-400 hover:text-stone-900 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Species Name</label>
                <input 
                  type="text" 
                  value={formData.species}
                  onChange={e => setFormData({...formData, species: e.target.value})}
                  placeholder="e.g. African Elephant"
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Common Name</label>
                  <input 
                    type="text" 
                    value={formData.commonName}
                    onChange={e => setFormData({...formData, commonName: e.target.value})}
                    placeholder="Common name"
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Scientific Name</label>
                  <input 
                    type="text" 
                    value={formData.scientificName}
                    onChange={e => setFormData({...formData, scientificName: e.target.value})}
                    placeholder="Genus species"
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5 text-sm italic"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Behavior / Field Notes</label>
                <textarea 
                  value={formData.behavior}
                  onChange={e => setFormData({...formData, behavior: e.target.value})}
                  placeholder="What was it doing? (Hunting, feeding, resting...)"
                  rows={3}
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5 text-sm resize-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">Location Name</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input 
                    type="text" 
                    value={formData.locationName}
                    onChange={e => setFormData({...formData, locationName: e.target.value})}
                    placeholder="e.g. Serengeti National Park"
                    className="w-full pl-10 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-stone-900/5 text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-200">
                <div className="flex items-center gap-3">
                  {formData.isPublic ? <Globe className="w-5 h-5 text-emerald-600" /> : <Lock className="w-5 h-5 text-stone-400" />}
                  <div>
                    <p className="text-sm font-medium">{formData.isPublic ? 'Public Sighting' : 'Private Sighting'}</p>
                    <p className="text-[10px] text-stone-400 uppercase tracking-wider">Visibility</p>
                  </div>
                </div>
                <button 
                  onClick={() => setFormData({...formData, isPublic: !formData.isPublic})}
                  className={cn(
                    "w-12 h-6 rounded-full transition-all relative",
                    formData.isPublic ? "bg-emerald-500" : "bg-stone-300"
                  )}
                >
                  <div className={cn(
                    "absolute top-1 w-4 h-4 bg-white rounded-full transition-all",
                    formData.isPublic ? "right-1" : "left-1"
                  )} />
                </button>
              </div>
            </div>

            <div className="flex gap-4 pt-4">
              <button 
                onClick={onClose}
                className="flex-1 px-8 py-4 border border-stone-200 rounded-2xl font-medium hover:bg-stone-50 transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={handleSave}
                disabled={isSaving || !formData.species}
                className="flex-[2] px-8 py-4 bg-stone-900 text-white rounded-2xl font-medium hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg flex items-center justify-center gap-2"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Sighting'
                )}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
